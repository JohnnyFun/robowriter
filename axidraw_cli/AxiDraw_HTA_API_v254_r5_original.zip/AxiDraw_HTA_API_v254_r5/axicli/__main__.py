from .axidraw_cli import axidraw_CLI
from .hta_cli import hta_CLI

def main():
    axidraw_CLI()

if __name__ == '__main__':
    main()
